"UTF-8"

function loadJSFunctional(jsFileName) {
	  var xhttp = new XMLHttpRequest();
	  xhttp.open("GET", './functionals/'+jsFileName+'.js', false);
	  xhttp.send();
	  if(xhttp.status === 200)
		  return xhttp.responseText;
	  return '';
}

function loadJSFunctionalFrom(rootPathOrRef,jsFileName) {
	return 'function activity(){ \n'+
		   'writeLine("'+rootPathOrRef+'/functionals/'+jsFileName+'.js"); \n'+
		   'writeLine("Podrzani protokoli : http, https"); \n'+
		   'writeLine("Nepodrzani protokoli : ftp, file"); \n'+
		   'writeLine("Kod je potrebno izvsavati na nekom serveru."); \n'+
		   "}";
}

