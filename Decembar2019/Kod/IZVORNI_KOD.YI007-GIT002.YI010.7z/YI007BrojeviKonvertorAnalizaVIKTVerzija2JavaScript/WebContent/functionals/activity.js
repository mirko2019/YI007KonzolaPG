"UTF-8"

function activity(){
	write('Unesi liniju koda : ');
	readLine(); 
	writeLine('Unesena linija koda je : '+getInput(actionsEnviroment));
}