package yi.programiranje.algorithm;

import java.math.BigInteger;

import yi.programiranje.model.ArabNumber;

public class FactorialTools {
	private ArabNumber number = new ArabNumber();

	public ArabNumber getNumber() {
		return number;
	}

	public void setNumber(ArabNumber number) {
		if(number == null) number = new ArabNumber(); 
		if(number.getNumber().compareTo(new BigInteger("1000"))>0)
			throw new RuntimeException("Algoritam podrzava operand 0-1000");
		this.number = number;
	} 
	
	public ArabNumber factoriel() {
		if(number.getNumber().compareTo(new BigInteger("0"))==0) {
			ArabNumber number = new ArabNumber();
			number.setFromString("1");
			return number; 
		}
		BigInteger product = new BigInteger("1");
		BigInteger incrementer = new BigInteger("1");
		
		while(incrementer.compareTo(number.getNumber())<=0) {
			product = product.multiply(incrementer); 
			incrementer = incrementer.add(new BigInteger("1")); 
		}
		
		ArabNumber number = new ArabNumber();
		number.setNumber(product);
		return number; 
	}
}
