package yi.programiranje.algorithm;

import java.math.BigInteger;

import yi.programiranje.model.ArabNumber;

public class PowerTools {
	private ArabNumber base = new ArabNumber();
	private ArabNumber exponent = new ArabNumber();
	
	{exponent.setFromString("1");}
	
	public ArabNumber getBase() {
		return base;
	}
	public void setBase(ArabNumber base) {
		if(base==null)
			base = new ArabNumber(); 
		
		boolean firstZero = base.getNumber().compareTo(new BigInteger("0"))==0; 
		boolean secondZero = exponent.getNumber().compareTo(new BigInteger("0"))==0;
		if(firstZero && secondZero)
			throw new RuntimeException("Nedozvoljeni baza i eksponent da budu nula istovremeno");
			
		int baseCountDigit = base.getNumber().toString().length(); 
		if(new BigInteger(Integer.toString(baseCountDigit+1).toString()).multiply(exponent.getNumber()).compareTo(new BigInteger("10000"))>0) 
			throw new RuntimeException("Granicna procjena rezultata na preko 10000 cifara.");
		
		this.base = base;
	}
	public ArabNumber getExponent() {
		return exponent;
	}
	public void setExponent(ArabNumber exponent) {
		boolean firstZero = base.getNumber().compareTo(new BigInteger("0"))==0; 
		boolean secondZero = exponent.getNumber().compareTo(new BigInteger("0"))==0;
		if(firstZero && secondZero)
			throw new RuntimeException("Nedozvoljeni baza i eksponent da budu nula istovremeno");
			
		int baseCountDigit = base.getNumber().toString().length(); 
		if(new BigInteger(Integer.toString(baseCountDigit+1).toString()).multiply(exponent.getNumber()).compareTo(new BigInteger("10000"))>0) 
			throw new RuntimeException("Granicna procjena rezultata na preko 10000 cifara.");
		
		this.exponent = exponent;
	} 
	
	public ArabNumber power() {
		if(base.getNumber().compareTo(new BigInteger("0"))==0) {
			return new ArabNumber(); 
		}
		if(base.getNumber().compareTo(new BigInteger("1"))==0) {
			ArabNumber number =  new ArabNumber(); 
			number.setFromString("1");
			return number; 
		}
		if(exponent.getNumber().compareTo(new BigInteger("1"))==0) {
			ArabNumber number =  new ArabNumber(); 
			number.setFromString("1");
			return number; 
		}
		BigInteger product = new BigInteger("1");
		BigInteger increment = new BigInteger("1");
		

		while(increment.compareTo(exponent.getNumber())<=0) {
			product = product.multiply(base.getNumber()); 
			increment = increment.add(new BigInteger("1")); 
		}
		
		ArabNumber number = new ArabNumber();
		number.setNumber(product);
		return number; 
	}
}
