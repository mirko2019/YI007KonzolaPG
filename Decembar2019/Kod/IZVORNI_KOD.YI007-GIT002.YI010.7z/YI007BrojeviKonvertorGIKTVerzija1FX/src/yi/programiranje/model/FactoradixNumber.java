package yi.programiranje.model;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class FactoradixNumber {
	private ArrayList<Integer> number = new ArrayList<>();
	
	public FactoradixNumber() {
		number.add(0); 
	}
	
	public synchronized List<Integer> getNumber(){
		return new ArrayList<>(number); 
	}
	
	public synchronized void setNumber(List<Integer> number) {
		ArrayList<Integer> nNumber = new ArrayList<>(); 
		
		if(number.size()==0) throw new RuntimeException("Neispravan broj cifara.");
		int length = number.size(); 
		
		if(number.size()==1 && number.get(0)==0) {
			nNumber.add(0); 
			this.number = nNumber; 
			return; 
		}
		
		for(;length>0; length--) {
			if(number.get(length-1)!=0) break; 
		}
		
		for(int i=0; i<length; i++) {
			if(number.get(i)<0) throw new RuntimeException("Negativna cifra. ");
			if(number.get(i)>=(i+1)) throw new RuntimeException("Cifra "+(i+1)+" van opsga baze.");
			nNumber.add(number.get(i)); 
		}
	
		this.number = nNumber;
	}
	
	public synchronized String to() {
		String num = "0"; 
		for(int i=1; i<number.size(); i++) {
			if(i<36)
				num = Integer.toString(number.get(i), i+1)+num; 
			else if(number.get(i)<36)
				num = Integer.toString(number.get(i),36)+num; 
			else
				num = "("+Integer.toString(number.get(i))+")"+num;
		}
		return num; 
	}
	
	public synchronized void from(String str) {
		ArrayList<Integer> number = new ArrayList<>(); 
		int radix = str.length();
		for(char c: str.toCharArray()) { 
			if(radix>1)
				number.add(0, Integer.parseInt(""+c, radix));
			else {
				if(c=='0') number.add(0,0); 
				else throw new RuntimeException("Cifra na bazi i poziciji 1 neispravna.");
			}
		}
		setNumber(number);
	}
	
	public synchronized String toGeneral() {
		String res = ""; 
		for(int i=0; i<number.size(); i++) {
			res="("+number.get(i)+")"+res; 
		}
		return res; 
	}
	
	public synchronized String toGeneral(int digitRadix) {
		String res = ""; 
		for(int i=0; i<number.size(); i++) {
			res="("+Integer.toString(number.get(i),digitRadix)+")"+res; 
		}
		return res; 
	}
	
	public synchronized void fromGeneral(String textNumber) {
		 String patternString = "\\([a-zA-Z0-9]+?\\)";
		 ArrayList<Integer> res = new ArrayList<>(); 
		 ArrayList<String> strings = new ArrayList<>(); 
		 
	     Pattern pattern = Pattern.compile(patternString);
	     Matcher matcher = pattern.matcher(textNumber);

	     int lastIndex = 0;
	     while(matcher.find()) {
	    	 int a = matcher.start(); 
	    	 int b = matcher.end(); 
	    	 int len = b-a; 
	    	 
	         if(lastIndex!=a) throw new RuntimeException("Opsta forma broja za bazu zapisa cifara 10 neispravna.");
	         strings.add(0, textNumber.substring(a+1, a+len-1)); 
	         lastIndex = b;
	     }
	     if(lastIndex!=textNumber.length())
	    	 throw new RuntimeException("Opsta forma broja za bazu zapisa cifara 10 neispravna.");
	     Collections.reverse(strings);
	     
	     for(int i=0; i<strings.size(); i++) {
	    	 String digit = strings.get(i); 
	    	 int digitValue = Integer.parseInt(digit); 
	    	 res.add(0,digitValue); 
	     }
	     
	     setNumber(res);
	}
	
	public synchronized void fromMixed(String textNumber) {
		 String patternString = "(\\([a-zA-Z0-9]+?\\))|([a-zA-Z0-9]+?)";
		 ArrayList<Integer> res = new ArrayList<>(); 
		 ArrayList<String> strings = new ArrayList<>(); 
		 
	     Pattern pattern = Pattern.compile(patternString);
	     Matcher matcher = pattern.matcher(textNumber);

	     int lastIndex = 0;
	     while(matcher.find()) {
	    	 int a = matcher.start(); 
	    	 int b = matcher.end(); 
	    	 int len = b-a; 
	    	 
	         if(lastIndex!=a) throw new RuntimeException("Opsta forma broja za bazu zapisa cifara 10 neispravna.");
	         if(textNumber.substring(a).startsWith("("))
	         	strings.add(0, textNumber.substring(a+1, a+len-1));
	         else
	        	strings.add(0, Integer.toString(Integer.parseInt(textNumber.substring(a, b), 36)));
	         lastIndex = b;
	     }
	     if(lastIndex!=textNumber.length())
	    	 throw new RuntimeException("Opsta forma broja za bazu zapisa cifara 10 neispravna.");
	     Collections.reverse(strings);
	     
	     for(int i=0; i<strings.size(); i++) {
	    	 String digit = strings.get(i); 
	    	 int digitValue = Integer.parseInt(digit); 
	    	 res.add(0,digitValue); 
	     }
	     
	     setNumber(res);
	}
	
	public synchronized void fromMixed(String textNumber, int radix) {
		 String patternString = "(\\([a-zA-Z0-9]+?\\))|([a-zA-Z0-9]+?)";
		 ArrayList<Integer> res = new ArrayList<>(); 
		 ArrayList<String> strings = new ArrayList<>(); 
		 
	     Pattern pattern = Pattern.compile(patternString);
	     Matcher matcher = pattern.matcher(textNumber);

	     int lastIndex = 0;
	     while(matcher.find()) {
	    	 int a = matcher.start(); 
	    	 int b = matcher.end(); 
	    	 int len = b-a; 
	    	 
	         if(lastIndex!=a) throw new RuntimeException("Opsta forma broja za bazu zapisa cifara 10 neispravna.");
	         if(textNumber.substring(a).startsWith("("))
	         	strings.add(0, textNumber.substring(a+1, a+len-1)); 
	         else
	        	strings.add(0, Integer.toString(Integer.parseInt(textNumber.substring(a,b), 36), radix));
	         lastIndex = b;
	     }
	     if(lastIndex!=textNumber.length())
	    	 throw new RuntimeException("Opsta forma broja za bazu zapisa cifara 10 neispravna.");
	     Collections.reverse(strings); 
	   
	     for(int i=0; i<strings.size(); i++) {
	    	 String digit = strings.get(i); 
	    	 int digitValue = Integer.parseInt(digit,radix); 
	    	 res.add(0,digitValue); 
	     }
	     
	     setNumber(res);
	}
	
	public synchronized void fromGeneral(String textNumber, int radix) {
		 String patternString = "\\([a-zA-Z0-9]+?\\)";
		 ArrayList<Integer> res = new ArrayList<>(); 
		 ArrayList<String> strings = new ArrayList<>(); 
		 
	     Pattern pattern = Pattern.compile(patternString);
	     Matcher matcher = pattern.matcher(textNumber);

	     int lastIndex = 0;
	     while(matcher.find()) {
	    	 int a = matcher.start(); 
	    	 int b = matcher.end(); 
	    	 int len = b-a; 
	    	 
	         if(lastIndex!=a) throw new RuntimeException("Opsta forma broja za bazu zapisa cifara 10 neispravna.");
	         strings.add(0, textNumber.substring(a+1, a+len-1)); 
	         lastIndex = b;
	     }
	     if(lastIndex!=textNumber.length())
	    	 throw new RuntimeException("Opsta forma broja za bazu zapisa cifara 10 neispravna.");
	     Collections.reverse(strings);
	     
	     for(int i=0; i<strings.size(); i++) {
	    	 String digit = strings.get(i); 
	    	 int digitValue = Integer.parseInt(digit, radix); 
	    	 res.add(0,digitValue); 
	     }
	     
	     setNumber(res);
	}
	
	public BigInteger toInteger() {
		BigInteger res = new BigInteger("0");
		BigInteger increment = new BigInteger("1");
		BigInteger radix = new BigInteger("1");
		
		for(int i=1; i<number.size(); i++) {
			BigInteger digit = new BigInteger(number.get(i).toString());
			res = res.add(digit.multiply(radix));
			increment = increment.add(new BigInteger("1")); 
			radix = radix.multiply(increment); 
		}
		
		return res; 
	}
	
	public void fromInteger(BigInteger integer) {
		ArrayList<Integer> value = new ArrayList<>(); 
		if(integer.compareTo(new BigInteger("0"))<0)
			throw new RuntimeException("Negativan broj.");
		if(integer.compareTo(new BigInteger("0"))==0) {
			value.add(0); 
			number = value; 
			return; 
		}
		BigInteger base = new BigInteger("1");
		while(integer.compareTo(new BigInteger("0"))>0) {
			value.add(integer.mod(base).intValue());
			integer = integer.divide(base); 
			base = base.add(new BigInteger("1")); 
		}
		number = value; 
	}
}
