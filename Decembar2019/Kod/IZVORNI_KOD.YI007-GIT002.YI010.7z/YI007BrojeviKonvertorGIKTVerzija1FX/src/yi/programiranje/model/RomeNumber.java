package yi.programiranje.model;

public class RomeNumber {
	private String number = "I";

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		if(number==null) number = "I";
		String old = this.number; 
		this.number = number;
		try {
			get(); 
		}catch(Exception ex) {
			this.number = old; 
			throw ex; 
		}
	} 
	
	public int get() {
		String[][] levels = {
			{"MMM", "MM", "M"}, 
			{"CM", "DCCC", "DCC", "DC", "D", "CD", "CCC", "CC", "C"}, 
			{"XC", "LXXX", "LXX", "LX", "L", "XL", "XXX", "XX", "X"},
			{"IX", "VIII", "VII", "VI", "V", "IV", "III", "II", "I"}
		};
		int res = 0; 
		int factor = 1000; 
		String x = number; 
		for(int i=0; i<4; i++) {
			for(int j=0; j<levels[i].length; j++) {
				if(x.startsWith(levels[i][j])) {
					res+=factor*(levels[i].length-j); 
					x = x.substring(levels[i][j].length()); 
				}
			}
			factor/=10; 
		}
		if(x.length()>0 || res==0)
			throw new RuntimeException("Neispravan format rimskog broja.");
		return res; 
	}
	
	public void set(int num) {
		if(num<1) throw new RuntimeException("Rimski broj mora biti u opsegu 1-3999.");
		if(num>3999) throw new RuntimeException("Rimski broj mora biti u opsegu 1-3999.");
		String res = ""; 
		switch(num/1000) {
			case 1: 
				res += "M"; 
				break; 
			case 2: 
				res += "MM"; 
				break; 
			case 3: 
				res += "MMM";
				break; 
		}
		num %=1000;
		switch(num/100) {
			case 1:
				res += "C";
				break; 
			case 2: 
				res += "CC"; 
				break; 
			case 3: 
				res += "CCC"; 
				break; 
			case 4: 
				res += "CD"; 
				break; 
			case 5:
				res += "D"; 
				break; 
			case 6: 
				res += "DC"; 
				break; 
			case 7: 
				res += "DCC";
				break; 
			case 8: 
				res += "DCCC"; 
				break; 
			case 9: 
				res += "CM"; 
				break; 
		}
		num %=100;
		switch(num/10) {
			case 1:
				res += "X";
				break; 
			case 2: 
				res += "XX"; 
				break; 
			case 3: 
				res += "XXX"; 
				break; 
			case 4: 
				res += "XL"; 
				break; 
			case 5:
				res += "L";
				break; 
			case 6: 
				res += "LX"; 
				break; 
			case 7: 
				res += "LXX";
				break; 
			case 8: 
				res += "LXXX"; 
				break; 
			case 9: 
				res += "XC";
				break; 
		}
		num %=10; 
		switch(num) {
			case 1:
				res += "I"; 
				break; 
			case 2: 
				res += "II"; 
				break; 
			case 3: 
				res += "III"; 
				break; 
			case 4: 
				res += "IV"; 
				break; 
			case 5:
				res += "V"; 
				break; 
			case 6: 
				res += "VI"; 
				break; 
			case 7: 
				res += "VII"; 
				break; 
			case 8: 
				res += "VIII";
				break; 
			case 9: 
				res += "IX"; 
				break; 
		}
		number = res; 
	}
}
