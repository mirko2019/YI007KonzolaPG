package yi.programiranje.model;

import java.math.BigInteger;

public class ArabNumber {
	private BigInteger number = new BigInteger("0");

	public BigInteger getNumber() {
		return number;
	}

	public void setNumber(BigInteger number) {
		if(number==null) number = new BigInteger("0");
		if(number.compareTo(new BigInteger("0"))<0) 
			throw new RuntimeException("Negativni brojevi nisu podrzani.");
		this.number = number;
	}
	
	public String getToString() {
		return number.toString(); 
	}
	
	public void setFromString(String number) {
		try {new BigInteger(number);}
		catch(Exception ex) {
			throw new RuntimeException("Nepodrzan format dekadnog broja.", ex);
		}
		BigInteger n = new BigInteger(number);
		if(n.compareTo(new BigInteger("0"))<0) 
			throw new RuntimeException("Negativni brojevi nisu podrzani.");
	}
}
