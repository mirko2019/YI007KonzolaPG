package yi.programiranje.contoller;

import java.math.BigInteger;

import yi.programiranje.model.RomeNumber;

public class RomeConvertor {
	private RomeNumber number = new RomeNumber();

	public RomeNumber getNumber() {
		return number;
	}

	public void setNumber(RomeNumber number) {
		if(number == null) number = new RomeNumber(); 
		this.number = number;
	} 
	
	public BigInteger get() {
		return new BigInteger(Integer.toString(number.get()));
	}
	
	public void set(BigInteger integer) {
		number.set(integer.intValue());
	}
}
