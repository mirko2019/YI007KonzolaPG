package yi.programiranje.contoller;

import java.math.BigInteger;

import yi.programiranje.model.ArabNumber;

public class FixBaseArabConvertor {
	private ArabNumber number;

	public ArabNumber getNumber() {
		return number;
	}

	public void setNumber(ArabNumber number) {
		if(number==null) number = new ArabNumber(); 
		this.number = number;
	} 
	
	public void from(String value, int radix) {
		if(radix<2 || radix>36) 
			throw new RuntimeException("Nepodrzana fiksna osnova "+radix+".");
		try {
			number.setNumber(new BigInteger(value,radix));
		}catch(Exception ex) {
			throw new RuntimeException("Nepodrzan format broja sa stalnom osnovom "+radix+" .", ex);
		}
	}
	
	public String to(int radix) {
		if(radix<2 || radix>36) 
			throw new RuntimeException("Nepodrzana fiksna osnova "+radix+".");
		return number.getNumber().toString(radix); 
	}
	
	public void fromDecade(String number) {
		from(number,10);
	}
	
	public String toDecade() {
		return to(10);
	}
	
	public void fromBinary(String number) {
		from(number, 2);
	}
	
	public String toBinary() {
		return to(2);
	}
	
	public void fromOctal(String number) {
		fromOctal(number);
	}
	
	public String toOctal() {
		return to(8);
	}
	
	public void fromHexadecimal(String number) {
		from(number,16); 
	}
	
	public String toHexadecimal() {
		return to(16); 
	}
}
