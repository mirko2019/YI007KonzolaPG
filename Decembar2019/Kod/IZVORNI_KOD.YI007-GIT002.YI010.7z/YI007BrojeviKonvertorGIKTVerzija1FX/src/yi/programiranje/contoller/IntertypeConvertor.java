package yi.programiranje.contoller;

import java.math.BigInteger;

import yi.programiranje.model.ArabNumber;
import yi.programiranje.model.FactoradixNumber;
import yi.programiranje.model.RomeNumber;

public class IntertypeConvertor {
	private BigInteger number;

	public BigInteger getNumber() {
		return number;
	}

	public void setNumber(BigInteger number) {
		if(number == null) number = new BigInteger("0");
		if(number.compareTo(new BigInteger("0"))<0)
			throw new RuntimeException("Negativni brojevi nisu podrzani.");
		this.number = number;
	} 
	
	public ArabNumber asArabNumber() {
		ArabNumber number = new ArabNumber();
		number.setNumber(this.number);
		return number;
	}
	
	public RomeNumber asRomeNumber() {
		RomeNumber number = new RomeNumber(); 
		number.set(this.number.intValue());
		return number; 
	}
	
	public FactoradixNumber asFactoradix() {
		FactoradixNumber number = new FactoradixNumber(); 
		number.fromInteger(this.number);
		return number; 
	}
	
	public FactoradixConvertor ganaerateAfineBaseConverter() {
		FactoradixConvertor converter = new FactoradixConvertor();
		converter.setNumber(asFactoradix());
		return converter; 
	}
	
	public FixBaseArabConvertor generateFixBaseConverter() {
		FixBaseArabConvertor convertor = new FixBaseArabConvertor(); 
		convertor.setNumber(asArabNumber());
		return convertor; 
	}
	
	public RomeConvertor generateRomeRecordDigitsConverter() {
		RomeConvertor convertor = new RomeConvertor();
		convertor.setNumber(asRomeNumber());
		return convertor; 
	}
}
