package yi.programiranje.contoller;

import java.math.BigInteger;

import yi.programiranje.model.FactoradixNumber;

public class FactoradixConvertor {
	private FactoradixNumber number = new FactoradixNumber();

	public FactoradixNumber getNumber() {
		return number;
	}

	public void setNumber(FactoradixNumber number) {
		if(number==null) number = new FactoradixNumber(); 
		this.number = number;
	} 
	
	public String toBasicFactoradixString() {
		return number.to(); 
	}
	
	public String toGeneralDecadeFactoradixString() {
		return number.toGeneral(); 
	}
	
	public String toGeneralOctalFactoradixString() {
		return number.toGeneral(8); 
	}
	
	public String toGeneralHexadecimalFactoradixString() {
		return number.toGeneral(16); 
	}
	
	public String toGeneralBinaryFactoradixString() {
		return number.toGeneral(2); 
	}
	
	public String toDecadeString() {
		return number.toInteger().toString(); 
	}
	
	public String toOctalString() {
		return number.toInteger().toString(8); 
	}
	
	public String toHexadecimalString() {
		return number.toInteger().toString(16); 
	}
	
	public String toBinaryString() {
		return number.toInteger().toString(2); 
	}
	
	public void fromBinaryString(String str) {
		number.fromInteger(new BigInteger(str,2));
	}
	
	public void fromOctalString(String str) {
		number.fromInteger(new BigInteger(str,8));
	}
	
	public void fromDecadeString(String str) {
		number.fromInteger(new BigInteger(str,10));
	}
	
	public void fromHexadecimalString(String str) {
		number.fromInteger(new BigInteger(str,16));
	}
	
	public void fromBasicFactoradix(String factoradix) {
		number.from(factoradix);
	}
	
	public void fromDecadeGeneralFactoradix(String frx) {
		number.fromGeneral(frx);
	}
	
	public void fromHexadecimalGeneralFactoradix(String frx) {
		number.fromGeneral(frx,16);
	}
	
	public void fromOctalGeneralFactoradix(String frx) {
		number.fromGeneral(frx,8);
	}
	
	public void fromBinaryGeneralFactoradix(String frx) {
		number.fromGeneral(frx,2);
	}
}
