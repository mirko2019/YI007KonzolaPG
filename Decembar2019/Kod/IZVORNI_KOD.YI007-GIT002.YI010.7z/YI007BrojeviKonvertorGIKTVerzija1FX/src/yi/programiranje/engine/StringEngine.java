package yi.programiranje.engine;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import yi.programiranje.algorithm.FactorialTools;
import yi.programiranje.model.FactoradixNumber;

public class StringEngine {
	private String string; 
	private BigInteger countDeploys; 
	
	public StringEngine(String string) {
		FactorialTools factCalculator = new FactorialTools();
		this.string = string; 
		factCalculator.getNumber().setNumber(new BigInteger(Integer.toString(length())));
		countDeploys = factCalculator.factoriel().getNumber(); 
	}
	
	public String getString() {
		return string; 
	}
	
	public String reverse() {
		StringBuilder sb = new StringBuilder(string); 
		return sb.reverse().toString(); 
	}
	
	public String sortedLexicalDirect() {
		char[] chars = string.toCharArray();
		Arrays.sort(chars); 
		return new String(chars);
	}
	
	public String sortedLexicalReverse() {
		char[] chars = string.toCharArray();
		Arrays.sort(chars); 
		return new StringBuilder(new String(chars)).reverse().toString();
	}
	
	public int length() {
		return string.length(); 
	}
	
	public BigInteger countDeploys() {
		return countDeploys; 
	}
	
	public String getDeplyNo(BigInteger number) {
		if(number==null) return null; 
		if(number.compareTo(new BigInteger("0"))<0) return null;
		if(number.compareTo(countDeploys)>=0) return null; 
		String res = ""; 
		
		String sorted = sortedLexicalDirect(); 
		ArrayList<String> chStrings = new ArrayList<>();
		for(char c: sorted.toCharArray()){
			chStrings.add(""+c); 
		}
		
		FactoradixNumber frx = new FactoradixNumber();
		frx.fromInteger(number);
		List<Integer> frxDigits = frx.getNumber();
		
		for(int i=frxDigits.size(); i<length(); i++) {
			frxDigits.add(0);  
		}
		
		Collections.reverse(frxDigits);
		
		for(int index: frxDigits) {
			res += chStrings.get(index); 
			chStrings.remove(index); 
		}
		return res; 
	}
	
	public BigInteger firstIndexOf() {
		String sorted = sortedLexicalDirect(); 
		ArrayList<String> chStrings = new ArrayList<>();
		for(char c: sorted.toCharArray()){
			chStrings.add(""+c); 
		}
		
		ArrayList<String> strings = new ArrayList<>();
		for(char c: string.toCharArray()) {
			strings.add(""+c);
		}
		
		ArrayList<Integer> index = new ArrayList<>(); 
		for(int i=0; i<string.length(); i++) {
			index.add(0, chStrings.indexOf(strings.get(i)));
			chStrings.remove(chStrings.indexOf(strings.get(i))); 
		}
		
		FactoradixNumber frx = new FactoradixNumber();
		frx.setNumber(index);
		
		return frx.toInteger(); 
	}
	
	public boolean apply(String str) {
		if(str==null) return false; 
		StringEngine se = new StringEngine(str);
		if(!sortedLexicalDirect().contentEquals(se.sortedLexicalDirect()))
			return false; 
		this.string = str; 
		return true; 
	}
	
	public boolean apply(BigInteger index) {
		String str = this.getDeplyNo(index);
		if(str==null) return false; 
		return apply(str); 
	}
	
	public List<String> getDeployOn(BigInteger index, int length){
		ArrayList<String> results = new ArrayList<>();
		if(index==null) return results; 
		if(index.compareTo(new BigInteger("0"))<0) index = new BigInteger("0");
		for(int i=0; i<length; i++) {
			if(index.compareTo(this.countDeploys)>=0) break; 
			results.add(this.getDeplyNo(index));
			index = index.add(new BigInteger("1")); 
		}
		return results; 
	}
}
