package yi.programiranje.program.gui;

import yi.programiranje.konzola.gui.KonzolaProgram;
import yi.programiranje.program.cli.Program;

public class Main {
	public static void main(String ... args) {
		KonzolaProgram.setAction(()->Program.main(args));
		KonzolaProgram.setTitle("Бројеви");
		KonzolaProgram.main(args);
	}
}
