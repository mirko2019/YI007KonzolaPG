package yi.programiranje.program.cli;

import java.math.BigInteger;
import java.util.List;
import java.util.Scanner;

import yi.programiranje.algorithm.FactorialTools;
import yi.programiranje.contoller.FactoradixConvertor;
import yi.programiranje.contoller.FixBaseArabConvertor;
import yi.programiranje.contoller.RomeConvertor;
import yi.programiranje.engine.StringEngine;
import yi.programiranje.model.ArabNumber;
import yi.programiranje.model.FactoradixNumber;
import yi.programiranje.program.util.text.TextTableMaystor;

public class Program {
	private static Scanner scanner = new Scanner(System.in);
	private static FactorialTools factoriel = new FactorialTools(); 
	private static FixBaseArabConvertor fixBasedNumber = new FixBaseArabConvertor(); 
	private static RomeConvertor romeNumber = new RomeConvertor(); 
	private static FactoradixConvertor afineBasedNumber = new FactoradixConvertor(); 
	
	public static int menu() {
		System.out.println("MENI : ");
		System.out.println("0. Izlaz");
		System.out.println("1. Racunanje faktorijela");
		System.out.println("2. Prtvorba dekadnog arapskog broja u ostale");
		System.out.println("3. Prtvorba oktalnog arapskog broja u ostale");
		System.out.println("4. Prtvorba binarnog arapskog broja u ostale");
		System.out.println("5. Prtvorba heksadecimalnog broja u ostale");
		System.out.println("6. Prtvorba rimskog broja u ostale");
		System.out.println("7. Prtvorba faktoradiksa (faktorijelnog broja)");
		System.out.println("8. Zapis faktorijela kroz brojne sisteme");
		System.out.println("9. Pronalazenje zadate permutacije datog broja"); 
		System.out.println("10. Pretvaranje broja u zadatu fiksnu bazu");
		System.out.println("11. Pretvaranje broja iz zadate fiksne baze"); 
		System.out.print("IZBOR: "); 
		try {
			return scanner.nextInt(); 
		}catch(Exception ex) {
			scanner = new Scanner(System.in); 
			return -1; 
		}
	}
	public static void main(String ... args) {
		System.out.println(">> BROJEVI - KONVERTORI BROJEVA - DOBRODOSLNI <<");
		while(true) {
			System.out.println();
			int izbor = menu(); 
			if(izbor==0) break;
			System.out.println(); 
			switch(izbor) {
				case 1:
					function1();
					break; 
				case 2: 
					function2();
					break; 
				case 3: 
					function3();
					break; 
				case 4: 
					function4(); 
					break; 
				case 5: 
					function5(); 
					break; 
				case 6: 
					function6(); 
					break; 
				case 7: 
					function7(); 
					break; 
				case 8: 
					function8(); 
					break;
				case 9: 
					function9(); 
					break; 
				case 10: 
					function10(); 
					break; 
				case 11: 
					function11(); 
					break; 
				default: 
					System.out.println("POGRESAN IZBOR!");
					break; 
			}
		}
		System.out.println(); 
		System.out.println(">> BROJEVI - KONVERTORI BROJEVA - DOVIDJENJA  <<");
	}
	
	public static void function1() {
		System.out.println("RACUNANJE FAKTORIJELA");
		while(true) {
			System.out.print("Unesi vrijednost operanda 0-1000 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.compareTo(new BigInteger("1000"))>0) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				factoriel.setNumber(numa);
				BigInteger res = factoriel.factoriel().getNumber(); 
				if(res.toString().length()>100) {
					System.out.println(num.toString()+"! = ");
					for(int i=0; i<res.toString().length(); i++) {
						if(i%100==0) System.out.print("\n\t");
						System.out.print(res.toString().charAt(i));
					}
					System.out.println("\n"); 
				}else {
					System.out.println(num.toString()+"! = "+res.toString());	
				}
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public static void function2() {
		System.out.println("PRETVORBA DEKADNOG BROJA U OSTALE FORMATE");
		while(true) {
			System.out.print("Unesi vrijednost broja 1-10000 cifara, veca od 0 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				System.out.println("BINARNO"); binaryPrint(); 
				System.out.println("OKTALNO"); octalPrint(); 
				System.out.println("DEKADNO"); decadePrint(); 
				System.out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(num.compareTo(new BigInteger("4000"))<0) 
					System.out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					System.out.println("RIMSKI : Nije definisan.");
				
				System.out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				System.out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				System.out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public static void function3() {
		System.out.println("PRETVORBA OKTALNOG BROJA U OSTALE FORMATE");
		while(true) {
			System.out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums,8);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				System.out.println("BINARNO"); binaryPrint(); 
				System.out.println("OKTALNO"); octalPrint(); 
				System.out.println("DEKADNO"); decadePrint(); 
				System.out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(num.compareTo(new BigInteger("4000"))<0) 
					System.out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					System.out.println("RIMSKI : Nije definisan.");
				
				System.out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				System.out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				System.out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public static void function4() {
		System.out.println("PRETVORBA BINARNOG BROJA U OSTALE FORMATE");
		while(true) {
			System.out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums,2);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				System.out.println("BINARNO"); binaryPrint(); 
				System.out.println("OKTALNO"); octalPrint(); 
				System.out.println("DEKADNO"); decadePrint(); 
				System.out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(num.compareTo(new BigInteger("4000"))<0) 
					System.out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					System.out.println("RIMSKI : Nije definisan.");
				
				System.out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				System.out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				System.out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public static void function5() {
		System.out.println("PRETVORBA HEKSADECIMALNOG BROJA U OSTALE FORMATE");
		while(true) {
			System.out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums,16);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				System.out.println("BINARNO"); binaryPrint(); 
				System.out.println("OKTALNO"); octalPrint(); 
				System.out.println("DEKADNO"); decadePrint(); 
				System.out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(num.compareTo(new BigInteger("4000"))<0) 
					System.out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					System.out.println("RIMSKI : Nije definisan.");
				
				System.out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				System.out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				System.out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public static void function6() {
		System.out.println("PRETVORBA RIMSKOG BROJA U OSTALE FORMATE");
		while(true) {
			System.out.print("Unesi vrijednost rimskog broja npr. I : ");
			String nums = scanner.next(); 
			try {
				romeNumber.getNumber().setNumber(nums);
				BigInteger num = romeNumber.get();
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				System.out.println("BINARNO"); binaryPrint(); 
				System.out.println("OKTALNO"); octalPrint(); 
				System.out.println("DEKADNO"); decadePrint(); 
				System.out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(num.compareTo(new BigInteger("4000"))<0) 
					System.out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					System.out.println("RIMSKI : Nije definisan.");
				
				System.out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				System.out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				System.out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public static void function7() {
		System.out.println("PRETVORBA FAKTORADIKSA U OSTALE FORMATE");
		System.out.println("Kao cifre koriste se mala ili velika slova engleskog alfabeta [0-26] i cifre brojeva - poziciona baza - radiks");
		System.out.println("Ravnopravna specifikacija cifara je koristenje brojeva sa fiksnom bazom u zagradama da se oznace cifre");
		System.out.println("Unos u mjesovitoj notaciji npr. (11)b(10)987654(3)210. Primjer ...az(38)(10)a. Bitno je da format radiksa bude ispostovan i oznake.");
		System.out.println("Vidi se da sve cifre moraju biti navedene do vodece, a vodece nule ne smetaju.");
		System.out.println(); 
		while(true) {
			System.out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next();
			System.out.print("Unesi zadanu bazu za zapis cifara u zagradama[2-36]: ");
			try {
				int base = Integer.parseInt(scanner.next());
				if(base<2 || base>36) throw new RuntimeException("Neodgovarajuca baza za brojeve sa fiksnom bazom"); 
				FactoradixNumber formatter = new FactoradixNumber();
				formatter.fromMixed(nums, base);
				BigInteger num = formatter.toInteger();
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				System.out.println("BINARNO"); binaryPrint(); 
				System.out.println("OKTALNO"); octalPrint(); 
				System.out.println("DEKADNO"); decadePrint(); 
				System.out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				System.out.println("SA FIKSNOM BAZOM "+base); fixedBasePrint(base);
				if(num.compareTo(new BigInteger("4000"))<0) 
					System.out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					System.out.println("RIMSKI : Nije definisan.");
				
				System.out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				System.out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				System.out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public static void function8() {
		System.out.println("RACUNANJE FAKTORIJELA I ZAPIS PO BROJNIM SISTEMIMA");
		while(true) {
			System.out.print("Unesi vrijednost operanda 0-1000 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.compareTo(new BigInteger("1000"))>0) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				factoriel.setNumber(numa);
				numa.setNumber(factoriel.factoriel().getNumber()); 
				fixBasedNumber.setNumber(numa);
				if(numa.getNumber().compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(numa.getNumber());
				System.out.println("BINARNO"); binaryPrint(); 
				System.out.println("OKTALNO"); octalPrint(); 
				System.out.println("DEKADNO"); decadePrint(); 
				System.out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(numa.getNumber().compareTo(new BigInteger("4000"))<0) 
					System.out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					System.out.println("RIMSKI : Nije definisan.");
				
				System.out.println();
				afineBasedNumber.getNumber().fromInteger(numa.getNumber());
				System.out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				System.out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public static void function9() {
		System.out.println("PREGLED PERMUTACIJA PO LEKSIKOGRAFSKOM POREDKU ZA STRING");
		System.out.println();
		System.out.print("Unesi string : ");
		String line = scanner.nextLine();
		while(line.length()==0) {
			line = scanner.nextLine(); 
		}
		StringEngine lineEngine = new StringEngine(line); 
		System.out.println("Broj permutacija (razmjstaja znakova) : "+lineEngine.countDeploys()); 
		System.out.println("Indeks tekuceg razmjestaja [prvi]: "+lineEngine.firstIndexOf()); 
		System.out.println();
		BigInteger index = new BigInteger("0");
		int len = 0; 
		while(true) {
			try {
				System.out.print("Unesi pocetni indeks za pretragu : ");
				String ln = scanner.next();
				index = new BigInteger(ln);
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
		while(true) {
			try {
				System.out.print("Unesi broj permutacija od indeksa : ");
				len = scanner.nextInt();
				break; 
			}catch(Exception ex) {
				scanner = new Scanner(System.in); 
				continue; 
			}
		}
		List<String> result = lineEngine.getDeployOn(index, len); 
		System.out.println("\nPRONALAZCI");
		System.out.println(); 
		for(String res: result) {
			System.out.println("\t"+res); 
		}
	}
	
	public static void function10() {
		System.out.println("PRETVORBA DEKADNOG BROJA U BROJ SA ZADATOM FIKSNOM BAZOM I U OSTALE FORMATE");
		System.out.println("Kao cifre koriste se mala ili velika slova engleskog alfabeta [0-26]");
		while(true) {
			System.out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next();
			System.out.print("Unesi zadanu bazu [2-36]: ");
			try {
				int base = Integer.parseInt(scanner.next());
				if(base<2 || base>36) throw new RuntimeException("Neodgovarajuca baza za brojeve sa fiksnom bazom"); 
				BigInteger num = new BigInteger(nums,10);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				System.out.println("BINARNO"); binaryPrint(); 
				System.out.println("OKTALNO"); octalPrint(); 
				System.out.println("DEKADNO"); decadePrint(); 
				System.out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				System.out.println("SA FIKSNOM BAZOM "+base); fixedBasePrint(base);
				if(num.compareTo(new BigInteger("4000"))<0) 
					System.out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					System.out.println("RIMSKI : Nije definisan.");
				
				System.out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				System.out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				System.out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public static void function11() {
		System.out.println("PRETVORBA BROJA SA ZADATOM FIKSNOM BAZOM U OSTALE FORMATE");
		System.out.println("Kao cifre koriste se mala ili velika slova engleskog alfabeta [0-26]");
		while(true) {
			System.out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next();
			System.out.print("Unesi zadanu bazu [2-36]: ");
			try {
				int base = Integer.parseInt(scanner.next());
				if(base<2 || base>36) throw new RuntimeException("Neodgovarajuca baza za brojeve sa fiksnom bazom"); 
				BigInteger num = new BigInteger(nums,base);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				System.out.println("BINARNO"); binaryPrint(); 
				System.out.println("OKTALNO"); octalPrint(); 
				System.out.println("DEKADNO"); decadePrint(); 
				System.out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				System.out.println("SA FIKSNOM BAZOM "+base); fixedBasePrint(base);
				if(num.compareTo(new BigInteger("4000"))<0) 
					System.out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					System.out.println("RIMSKI : Nije definisan.");
				
				System.out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				System.out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				System.out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public static void  factoradixGeneralPrint() {
		List<Integer> digits = afineBasedNumber.getNumber().getNumber(); 
		String[][] mat = new String[digits.size()/10+(digits.size()%10==0?0:1)][10]; 
		for(int i=0; i<mat.length; i++) {
			mat[i] = new String[10]; 
			for(int j=0; j<mat[i].length; j++)
				mat[i][j]="0"; 
		}
		for(int i=0; i<digits.size(); i++) {
			mat[mat.length-i/10-1][i%10] = Integer.toString(digits.get(i)); 
		}
		TextTableMaystor tm = new TextTableMaystor(mat);
		mat = tm.fitTableStringize(); 
		
		for(int i=0; i<mat.length; i++) {
			System.out.println(); 
			for(int j=0; j<mat[i].length; j++)
				System.out.print(mat[i][mat[i].length-j-1]+" "); 
		}
		
		System.out.println();
	}
	
	public static void  factoradixBasicPrint() {
		String number = afineBasedNumber.toBasicFactoradixString(); 
		for(int i=0; i<number.length(); i++) {
			if(i%100==0) System.out.print("\n\t"); 
			System.out.print(number.charAt(i));
		}
		System.out.println();
		System.out.println(); 
	}
	
	public static void fixedBasePrint(int radix) {
		String number = fixBasedNumber.to(radix); 
		String pad = ""; 
		int padding = (5-number.length()%5)%5; 
		for(int i=0; i<padding; i++) {
			pad+="0"; 
		}
		number = pad+number;
		for(int i=0; i<number.length(); i++) {
			if(i%100==0) System.out.print("\n\t");
			if(i%5==0 && i%100!=0) System.out.print(" ");
			if(i%20==0 && i%100!=0) System.out.print(" ");
			System.out.print(number.charAt(i)); 
		}
		System.out.println();
		System.out.println();
	}
	
	public static void binaryPrint() {
		String number = fixBasedNumber.toBinary(); 
		String pad = ""; 
		int padding = (8-number.length()%8)%8;
		for(int i=0; i<padding; i++) {
			pad+="0"; 
		}
		number = pad+number; 
		for(int i=0; i<number.length(); i++) {
			if(i%64==0) System.out.print("\n\t");
			if(i%8==0 && i%64!=0) System.out.print(" ");
			if(i%16==0 && i%64!=0) System.out.print(" "); 
			System.out.print(number.charAt(i));
		}
		System.out.println();
		System.out.println();
	}
	
	public static void octalPrint() {
		String number = fixBasedNumber.toOctal(); 
		String pad = ""; 
		int padding = (3-number.length()%3)%3; 
		for(int i=0; i<padding; i++) {
			pad+="0"; 
		}
		number = pad+number;
		for(int i=0; i<number.length(); i++) {
			if(i%60==0) System.out.print("\n\t");
			if(i%3==0 && i%60!=0) System.out.print(" ");
			if(i%12==0 && i%60!=0) System.out.print(" "); 
			System.out.print(number.charAt(i));
		}
		System.out.println();
		System.out.println();
	}
	
	public static void decadePrint() {
		String number = fixBasedNumber.toDecade(); 
		String pad = ""; 
		int padding = (5-number.length()%5)%5; 
		for(int i=0; i<padding; i++) {
			pad+="0"; 
		}
		number = pad+number;
		for(int i=0; i<number.length(); i++) {
			if(i%100==0) System.out.print("\n\t");
			if(i%5==0 && i%100!=0) System.out.print(" ");
			if(i%20==0 && i%100!=0) System.out.print(" ");
			System.out.print(number.charAt(i)); 
		}
		System.out.println();
		System.out.println();
	}
	
	public static void hexadecimalPrint() {
		String number = fixBasedNumber.toHexadecimal();
		String pad = ""; 
		int padding = (2-number.length()%2)%2;
		for(int i=0; i<padding; i++) {
			pad+="0"; 
		}
		number = pad+number;
		for(int i=0; i<number.length(); i++) {
			if(i%64==0) System.out.print("\n\t");
			if(i%2==0 && i%64!=0) System.out.print(" ");
			if(i%16==0 && i%64!=0) System.out.print(" ");
			System.out.print(number.charAt(i));
		}
		System.out.println();
		System.out.println();
	}
}
