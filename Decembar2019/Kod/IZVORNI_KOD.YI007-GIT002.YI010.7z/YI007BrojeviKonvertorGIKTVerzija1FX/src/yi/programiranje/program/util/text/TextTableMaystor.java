package yi.programiranje.program.util.text;

import java.io.Serializable;

public class TextTableMaystor implements Serializable{
	private static final long serialVersionUID = 7762048984377981914L;
	
	private int rows=0;
	private int cols=0; 
	private String[][] content;
	
	public TextTableMaystor(String[][] matrix) {
		content = matrix; 
		rows = matrix.length;
		if(rows>0) cols = matrix[0].length;
	}

	public String[][] getContent() {
		return content;
	}

	public void setContent(String[][] content) {
		this.content = content;
	}
	
	public int rows() {
		return rows;
	}
	
	public int cols() {
		return cols;
	}
	
	public String maxStringInRow(int row) {
		if(row<0) return null; 
		if(row>=rows) return null; 
		int maxlen = 0; 
		String result = ""; 
		for(int j=0; j<cols; j++) {
			if(maxlen<content[row][j].length()) 
				result = content[row][j]; 
			maxlen = Math.max(maxlen,content[row][j].length()); 
		}
		return result; 
	}
	
	public String maxStringInColumn(int col) {
		if(col<0) return null; 
		if(col>=cols) return null; 
		int maxlen = 0; 
		String result = ""; 
		for(int i=0; i<rows; i++) {
			if(maxlen<content[i][col].length()) 
				result = content[i][col]; 
			maxlen = Math.max(maxlen,content[i][col].length()); 
		}
		return result; 
	}
	
	public String[][] fitTableStringize() {
		String [][] res = new String[rows][cols]; 
		int [] maxlens = new int[cols]; 
		for(int j=0; j<cols; j++)
			maxlens[j] = maxStringInColumn(j).length(); 
		for(int i=0; i<rows; i++)
			for(int j=0; j<cols; j++) {
				res[i][j] = content[i][j]; 
				for(int k=res[i][j].length(); k<maxlens[j]; k++)
					res[i][j]+=" "; 
			}
		return res; 
	}
}
