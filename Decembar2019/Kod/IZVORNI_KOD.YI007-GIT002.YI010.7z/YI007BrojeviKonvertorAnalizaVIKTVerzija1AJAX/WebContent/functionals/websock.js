"UTF-8"

let url = new URL(window.location.href);
var pageId; 
url.protocol = 'ws:';
url.port=8080; 
url.pathname = url.pathname.substr(0,url.pathname.indexOf('/',1))+'/KonzolaSignal';

let socket = new WebSocket(url.href);

socket.onopen = function(e) {
  console.log("Open signal socket. Otvorena signalna linija."); 
};

socket.onmessage = function(event) {
    pageId = event.data; 
	loadProgram(pageId, window.location.href);
	console.log("Message - poruka: "+event.data);
};

socket.onclose = function(event) {
  console.log("Closed signal socket. Zatvorena signalna linija.");
};

socket.onerror = function(error) {
	console.log("Signal socket error - greska konzolne linije : "+error.message);
};