"UTF-8"

var inputText = ''; 

function inputKeyPress(pageId, path, event){
	if(event.keyCode===13){
		var output = document.getElementById('output');
		var input = document.getElementById('input');
		inputText=input.value;
		output.value+=input.value+"\n";
		input.value = ''; 
		input.setAttribute('readonly','');
		query(pageId, path, getInputText()); 
		event.preventDefault(); 
	}
}

function clearInput(){
	document.getElementById('input').value='';
}

function clearOutput(){
	document.getElementById('output').value=''; 
}

function readLine(){
	var input = document.getElementById('input');
	input.removeAttribute('readonly');
}

function writeLine(text){
	var output = document.getElementById('output');
	output.value += text+"\n";
	output.scrollTop = output.scrollHeight;
}

function getInputText(){
	var result = inputText; 
	inputText=''; 
	return result; 
}


function write(text){
	var output = document.getElementById('output');
	output.value += text; 
	output.scrollTop = output.scrollHeight;
}

function loadProgram(pageId, path){
	clearInput(); 
	clearOutput();
	inputText = ''; 
	
	var input = document.getElementById('input');
	input.setAttribute('readonly','');
	query(pageId, path, null);
}
