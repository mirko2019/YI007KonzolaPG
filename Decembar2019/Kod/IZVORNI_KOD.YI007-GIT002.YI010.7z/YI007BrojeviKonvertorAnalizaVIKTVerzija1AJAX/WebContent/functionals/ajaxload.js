"UTF-8"

function query(pageId, path, param) {
	  var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
		    if (this.readyState == 4 && this.status == 200) {
		    	var resp = this.responseText;
		        var json = JSON.parse(resp); 
		        if(json.state=='output'){
		        	write(json.output); 
		        	query(pageId, path,null); 
		        }
		        else if(json.state=='input'){
		        	readLine(); 
		        }
		        else if(json.state=='clear_screen'){
		        	clearOutput(); 
		        	query(pageId,path,null); 
		        }
		        else if(json.state=='no_proccess'){
		        	query(pageId, path,null); 
		        	return; 
		        }else if(json.state!='end'){
		        	console.log("Greska.\n"+resp); 
		        }
		    }
	  }; 
	  xhttp.open("POST", path+'KonzolaServiceServlet', true);
	  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	  if(param===null || param==='') xhttp.send('type=request&page='+encodeURI(pageId));
	  else xhttp.send('type=request&input='+encodeURI(param)+"&page="+encodeURI(pageId));
}
