package yi.programiranje.konzola.web.model;

import java.io.Serializable;

import yi.programiranje.konzola.web.controller.KonzolaServiceServlet.ResponseInformation;
import yi.programiranje.konzola.web.controller.KonzolaServiceServlet.ResponseState;
import yi.programiranje.konzola.web.controller.KonzolaServiceServlet.ResponseType;

public class ResponseUnit implements Serializable{
	private static final long serialVersionUID = -4335523657154300165L;
	private ResponseType responseType = ResponseType.RESPONSE; 
	private String outputContent = ""; 
	private ResponseState responseState = ResponseState.OUTPUT; 
	private ResponseInformation responseInformation = ResponseInformation.COMMUNICATION; 
	private String messageContent = "";
	public ResponseType getResponseType() {
		return responseType;
	}
	public ResponseUnit setResponseType(ResponseType responseType) {
		if(responseType==null) throw new NullPointerException(); 
		this.responseType = responseType;
		return this; 
	}
	public String getOutputContent() {
		return outputContent;
	}
	public ResponseUnit setOutputContent(String outputContent) {
		if(outputContent==null) throw new NullPointerException(); 
		this.outputContent = outputContent;
		return this; 
	}
	public ResponseState getResponseState() {
		return responseState;
	}
	public ResponseUnit setResponseState(ResponseState responseState) {
		if(responseState==null) throw new NullPointerException(); 
		this.responseState = responseState;
		return this; 
	}
	public ResponseInformation getResponseInformation() {
		return responseInformation;
	}
	public ResponseUnit setResponseInformation(ResponseInformation responseInformation) {
		if(responseInformation==null) throw new NullPointerException(); 
		this.responseInformation = responseInformation;
		return this; 
	}
	public String getMessageContent() {
		return messageContent;
	}
	public ResponseUnit setMessageContent(String messageContent) {
		if(messageContent==null) throw new NullPointerException(); 
		this.messageContent = messageContent;
		return this; 
	} 
	
	public boolean isCommunication() {
		return responseState==ResponseState.OUTPUT; 
	}
	
	public boolean isFinalizer() {
		return responseState==ResponseState.END; 
	}
}
