package yi.programiranje.konzola.web.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.JsonObject;

import yi.programiranje.konzola.web.model.CommunicationController;
import yi.programiranje.konzola.web.model.RequestUnit;
import yi.programiranje.konzola.web.model.ResponseUnit;
import yi.programiranje.program.cli.WebConsoleApplication;

public class KonzolaServiceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final String REQUEST_TYPE = "type"; 
	public static final String REQUEST_PAGE = "page"; 
	public static final String REQUEST_INPUT = "input"; 
	public static final String RESPONSE_TYPE = "type";
	public static final String RESPONSE_OUTPUT = "output"; 
	public static final String RESPONSE_STATE = "state"; 
	public static final String RESPONSE_INFO = "info"; 
	public static final String RESPONSE_MESSAGE = "mmessage";
	
	
	public enum RequestType {
		REQUEST("request"); 
		private final String value; 
		private RequestType(String value) {
			this.value = value; 
		}
		public String toValue() {
			return value; 
		}
		public String toString() {
			return value;
		}
		
		public static RequestType getFor(String value) {
			if(value==null) return null; 
			for(RequestType rt: values()) {
				if(rt.toValue().contentEquals(value))
					return rt; 
			}
			return null; 
		}
	}

	public enum ResponseType {
		RESPONSE("response"), 
		INFORMATION("information");
		
		private final String value; 
		private ResponseType(String value) {
			this.value = value; 
		}
		public String toValue() {
			return value; 
		}
		public String toString() {
			return value;
		}
		
		public static ResponseType getFor(String value) {
			if(value==null) return null; 
			for(ResponseType rt: values()) {
				if(rt.toValue().contentEquals(value))
					return rt; 
			}
			return null; 
		}
	}
	
	public enum ResponseState {
		OUTPUT("output"), END("end"), INPUT("input"), CLEAR_SCREEN("clear_screen"), NO_PROCCESS("no_proccess"); 
		
		private final String value; 
		private ResponseState(String value) {
			this.value = value; 
		}
		public String toValue() {
			return value; 
		}
		public String toString() {
			return value;
		}
		
		public static ResponseState getFor(String value) {
			if(value==null) return null; 
			for(ResponseState rt: values()) {
				if(rt.toValue().contentEquals(value))
					return rt; 
			}
			return null; 
		}
	}
	
	public enum ResponseInformation {
		SUCCESS("success"), 
		ERROR("end"), 
		INFO("info"), 
		WARNNING("warrning"), 
		SIGNAL("signal"), 
		MESSAGE("message"),
		COMMUNICATION("communication"); 
		
		private final String value; 
		private ResponseInformation(String value) {
			this.value = value; 
		}
		public String toValue() {
			return value; 
		}
		public String toString() {
			return value;
		}
		
		public static ResponseInformation getFor(String value) {
			if(value==null) return null; 
			for(ResponseInformation rt: values()) {
				if(rt.toValue().contentEquals(value))
					return rt; 
			}
			return null; 
		}
	}
	
    public KonzolaServiceServlet() {
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestType type = RequestType.getFor(request.getParameter(REQUEST_TYPE)); 
		String input = request.getParameter(REQUEST_INPUT); 
		String pageId = request.getParameter(REQUEST_PAGE); 
		RequestUnit req = new RequestUnit(type, pageId, input);
		CommunicationController cmc = new CommunicationController(req); 
		
		ResponseUnit resp = cmc.getResponse();
		KonzolaServiceSignalizer signalizer = KonzolaServiceSignalizer.get(pageId); 
		JsonObject root = new JsonObject(); 
		if(signalizer==null) {
			resp.setResponseType(ResponseType.RESPONSE);
			resp.setResponseInformation(ResponseInformation.ERROR); 
			resp.setResponseState(ResponseState.END); 
			resp.setOutputContent("");
			resp.setMessageContent("Signalna sesija ne postoji. Losa identifikacija.");
			
			root.addProperty(RESPONSE_TYPE, resp.getResponseType().toString());
			root.addProperty(RESPONSE_STATE, resp.getResponseState().toString());
			root.addProperty(RESPONSE_INFO, resp.getResponseInformation().toString());
			root.addProperty(RESPONSE_MESSAGE, resp.getMessageContent().toString());
			root.addProperty(RESPONSE_OUTPUT, resp.getOutputContent().toString());
			response.setContentType("application/json");
			response.getWriter().println(root);
			return; 
		}
		if(cmc.getRequest().getInputContent()==null) {
			KonzolaServiceSupport support = KonzolaServiceSupport.getOrCreateSupport(signalizer, request.getSession(), WebConsoleApplication.class);		
			
			if(!support.getProgram().isStarted()) support.getWorker().getWorker().start();
			else if(!support.getProgram().isEndded()) {
				if(support.onInput()) {
					resp.setResponseState(ResponseState.INPUT); 
				}else if(support.onOutput()) {
					var kvos = support.getProgram().kvos; 
					synchronized(kvos) {
						resp.setOutputContent(new String(kvos.getContent()));
					}
				}
			}else if(support.getProgram().inError()){
				resp.setResponseState(ResponseState.END);
				((Exception)support.getProgram().error).printStackTrace();
				resp.setResponseInformation(ResponseInformation.ERROR);
				resp.setMessageContent(((Exception)support.getProgram().error).getMessage()); 
			}else{
				resp.setResponseState(ResponseState.END);
				var kvos = support.getProgram().kvos; 
				synchronized(kvos) {
					resp.setOutputContent(new String(kvos.getContent()));
				}
			}
		}else {
			KonzolaServiceSupport support = KonzolaServiceSupport.getOrCreateSupport(signalizer, request.getSession(), WebConsoleApplication.class);
			support.getWorker().getIOSupport().getInput().setContent(cmc.getRequest().getInputContent().getBytes("UTF-8")); 
			resp.setResponseState(ResponseState.NO_PROCCESS);
			resp.setMessageContent("");
			resp.setOutputContent("");
		}
		
		root.addProperty(RESPONSE_TYPE, resp.getResponseType().toString());
		root.addProperty(RESPONSE_STATE, resp.getResponseState().toString());
		root.addProperty(RESPONSE_INFO, resp.getResponseInformation().toString());
		root.addProperty(RESPONSE_MESSAGE, resp.getMessageContent().toString());
		root.addProperty(RESPONSE_OUTPUT, resp.getOutputContent().toString());
		response.setContentType("application/json");
		response.getWriter().println(root); 
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
