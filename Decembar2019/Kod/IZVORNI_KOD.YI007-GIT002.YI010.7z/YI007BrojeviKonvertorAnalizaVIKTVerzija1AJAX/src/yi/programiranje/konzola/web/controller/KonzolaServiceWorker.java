package yi.programiranje.konzola.web.controller;

import yi.programiranje.konzola.web.io.KonzolaVebStreamSupport;
import yi.programiranje.konzola.web.model.WebConsoleProgram;

public class KonzolaServiceWorker {
	private String id; 
	private KonzolaServiceSignalizer signalizer;
	private KonzolaVebStreamSupport ioSupport;
	private Thread worker; 
	private WebConsoleProgram job; 
	
	public KonzolaServiceWorker(KonzolaServiceSignalizer signalizer, KonzolaVebStreamSupport ioSupport, WebConsoleProgram job) {
		this.signalizer = signalizer;
		this.id = signalizer.getId(); 
		this.ioSupport = ioSupport; 
		this.job = job; 
		this.worker = new Thread(job);
	}

	public String getId() {
		return id;
	}

	public KonzolaServiceSignalizer getSignalizer() {
		return signalizer;
	}

	public Thread getWorker() {
		return worker;
	}

	public WebConsoleProgram getJob() {
		return job;
	}
	
	public KonzolaVebStreamSupport getIOSupport() {
		return ioSupport;
	}
}
