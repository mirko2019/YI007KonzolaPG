package yi.programiranje.konzola.web.listener;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import yi.programiranje.konzola.web.controller.KonzolaServiceSignalizer;
import yi.programiranje.konzola.web.controller.KonzolaServiceSupport;

public class SessionListener implements HttpSessionListener {

    public SessionListener() {
    }

    public void sessionCreated(HttpSessionEvent se)  { 
    }

    public void sessionDestroyed(HttpSessionEvent se)  { 
    	KonzolaServiceSignalizer.closeAll(KonzolaServiceSupport.getAll(se.getSession()).keySet());
    	KonzolaServiceSupport.stopAll(se.getSession());
    }
    
}
