package yi.programiranje.konzola.web.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.websocket.Session;

import yi.programiranje.konzola.web.ws.signal.KonzolaPageSignalServerWS;

public class KonzolaServiceSignalizer {
	private static HashMap<String, KonzolaServiceSignalizer> map = new HashMap<>();
	private Session pageSession; 
	private KonzolaPageSignalServerWS pageWebSocket; 
	
	public synchronized static void closeAll(String ... ids) {
		for(String id: ids) {
			close(id);
		}
	}
	public synchronized static void closeAll(Collection<String> ids) {
		for(String id: ids) {
			close(id);
		}
	}
	public synchronized static void closeAll() {
		for(var mEntry: getAll().entrySet()) {
			close(mEntry.getKey());
		}
	}
	public synchronized static void close(String id) {
		map.remove(id);
	}
	public synchronized static void close(Session session) {
		if(session==null) return; 
		map.remove(session.getId()); 
	}
	public synchronized static void close(KonzolaPageSignalServerWS webSocket) {
		for(var mapEntry: map.entrySet()) {
			if(mapEntry.getValue().pageWebSocket==webSocket) {
				map.remove(mapEntry.getKey());
				return; 
			}
		}
	}
	
	public synchronized static Map<String, KonzolaServiceSignalizer> getAll(){
		return new HashMap<>(map); 
	}
	public synchronized static KonzolaServiceSignalizer get(String id) {
		return map.get(id);
	}
	public synchronized static KonzolaServiceSignalizer get(Session session) {
		if(session==null) return null; 
		return map.get(session.getId()); 
	}
	public synchronized static KonzolaServiceSignalizer get(KonzolaPageSignalServerWS webSocket) {
		for(var mapEntry: map.entrySet()) {
			if(mapEntry.getValue().pageWebSocket==webSocket)
				return mapEntry.getValue(); 
		}
		return null;
	}
	
	
	
	public KonzolaServiceSignalizer(Session session, KonzolaPageSignalServerWS webSocket) {
		this.pageSession = session;
		map.put(session.getId(), this); 
	}

	public KonzolaPageSignalServerWS  getPageWebSocket() {
		return pageWebSocket; 
	}
	
	public Session getPageSession() {
		return pageSession;
	}
	
	public void close() {
		close(pageSession);
	}
	
	public String getId() {
		return pageSession.getId(); 
	}
}
