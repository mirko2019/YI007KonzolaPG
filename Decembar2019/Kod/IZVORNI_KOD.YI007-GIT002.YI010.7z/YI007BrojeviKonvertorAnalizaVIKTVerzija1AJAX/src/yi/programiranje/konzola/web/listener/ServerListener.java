package yi.programiranje.konzola.web.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import yi.programiranje.konzola.web.controller.KonzolaServiceSignalizer;
import yi.programiranje.konzola.web.controller.KonzolaServiceSupport;

public class ServerListener implements ServletContextListener {
    
	public ServerListener() {
    }

    public void contextDestroyed(ServletContextEvent sce)  { 
       	KonzolaServiceSignalizer.closeAll();
    	KonzolaServiceSupport.stopAll();
    }

    public void contextInitialized(ServletContextEvent sce)  {
    }
}
