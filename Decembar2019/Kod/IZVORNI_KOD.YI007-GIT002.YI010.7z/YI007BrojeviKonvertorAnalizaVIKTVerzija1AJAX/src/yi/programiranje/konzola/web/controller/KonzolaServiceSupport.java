package yi.programiranje.konzola.web.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import yi.programiranje.konzola.web.io.KonzolaVebInputStream;
import yi.programiranje.konzola.web.io.KonzolaVebOutputStream;
import yi.programiranje.konzola.web.io.KonzolaVebStreamSupport;
import yi.programiranje.konzola.web.model.WebConsoleProgram;

public class KonzolaServiceSupport {
	private static HashMap<String, KonzolaServiceSupport> map = new HashMap<>(); 
	
	private String id; 
	private KonzolaServiceWorker worker;
	private WebConsoleProgram program; 
	private HttpSession session; 
	
	public synchronized static Map<String, KonzolaServiceSupport> getAll(HttpSession session){
		HashMap<String, KonzolaServiceSupport> kss = new HashMap<>(); 
		for(var mEntry: map.entrySet()) {
			if(mEntry.getValue().getSession()==session) {
				kss.put(mEntry.getKey(), mEntry.getValue());
			}
		}
		return kss; 
	}
	public synchronized static Map<String, KonzolaServiceSupport> getAll() {
		return new HashMap<>(map); 
	}
	
	public synchronized static KonzolaServiceSupport get(String id) {
		return map.get(id); 
	}
	public synchronized static KonzolaServiceSupport get(KonzolaServiceSupport worker) {
		if(worker==null) return null; 
		return map.get(worker.getId()); 
	}
	
	public synchronized static void stopAll(HttpSession session) {
		for(String id: getAll(session).keySet()) {
			stop(id);
		}
	}
	public synchronized static void stopAll(String ... ids) {
		for(String id: ids) {
			stop(id);
		}
	}
	public synchronized static void stopAll(Collection<String> ids) {
		for(String id: ids) {
			stop(id);
		}
	}
	public synchronized static void stopAll() {
		for(var mEntry: getAll().entrySet()) {
			stop(mEntry.getKey());
		}
	}
	public synchronized static void stop(String id) {
		map.remove(id); 
	}
	public synchronized static void stop(KonzolaServiceSupport worker) {
		if(worker==null) return; 
		map.remove(worker.getId()); 
	}
	
	public synchronized static KonzolaServiceSupport getOrCreateSupport(KonzolaServiceSignalizer id, HttpSession session,  Class<? extends WebConsoleProgram> runnable) {
		try {
			KonzolaVebStreamSupport streamer = new KonzolaVebStreamSupport(); 
			WebConsoleProgram rnb = (WebConsoleProgram) runnable.getConstructor(KonzolaVebOutputStream.class, KonzolaVebInputStream.class, KonzolaVebOutputStream.class).newInstance(streamer.getOutput(), streamer.getInput(),streamer.getOutput());
			if(id==null) return null;
			id = KonzolaServiceSignalizer.get(id.getId()); 
			if(id==null) return null;
			var res = get(id.getId());
			if(res==null) {
				res = new KonzolaServiceSupport(new KonzolaServiceWorker(id,streamer, rnb), session);
				res.setProgram(rnb);
			}
			return res; 
		}catch(Exception ex) {
			throw new RuntimeException(ex);
		}
	}
	
	public KonzolaServiceSupport(KonzolaServiceWorker worker, HttpSession session) {
		this.id = worker.getId(); 
		this.worker = worker;
		this.session = session; 
		map.put(id,this);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public KonzolaServiceWorker getWorker() {
		return worker;
	}
	public void setWorker(KonzolaServiceWorker worker) {
		this.worker = worker;
	}
	public HttpSession getSession() {
		return session;
	}
	public void setSession(HttpSession session) {
		this.session = session;
	}
	public WebConsoleProgram getProgram() {
		return program; 
	}
	public void setProgram(WebConsoleProgram program) {
		this.program = program; 
	}
	
	public boolean onClearOutputScreen() {
		return worker.getIOSupport().onClearOutputScreen();
	}
	
	public boolean onInput() {
		return worker.getIOSupport().onInput();
	}
	
	public boolean onOutput() {
		return worker.getIOSupport().onOutput();
	}
}
