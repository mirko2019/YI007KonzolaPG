package yi.programiranje.konzola.web.model;

import java.io.Serializable;

public class CommunicationController implements Serializable{
	private static final long serialVersionUID = -2751824934914351725L;
	private RequestUnit request; 
	private ResponseUnit response; 
	
	public CommunicationController(RequestUnit request) {
		this.request = request; 
		this.response = new ResponseUnit(); 
	}

	public ResponseUnit getResponse() {
		return response;
	}

	public void setResponse(ResponseUnit response) {
		this.response = response;
	}

	public RequestUnit getRequest() {
		return request;
	}
}
