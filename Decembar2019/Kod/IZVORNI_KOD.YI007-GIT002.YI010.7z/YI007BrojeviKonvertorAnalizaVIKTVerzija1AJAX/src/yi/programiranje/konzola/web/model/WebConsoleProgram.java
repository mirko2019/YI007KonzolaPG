package yi.programiranje.konzola.web.model;

import java.io.InputStream;
import java.io.PrintStream;

import yi.programiranje.konzola.web.io.KonzolaVebInputStream;
import yi.programiranje.konzola.web.io.KonzolaVebOutputStream;

public abstract class WebConsoleProgram implements Runnable{
	public final KonzolaVebOutputStream kvos; 
	public final KonzolaVebInputStream kvis; 
	public final KonzolaVebOutputStream kverr; 
	public final InputStream in; 
	public final PrintStream out; 
	public final PrintStream err; 
	public Throwable error; 
	public boolean endded = false; 
	public boolean stareted = false;
	
	public WebConsoleProgram(KonzolaVebOutputStream kvos, KonzolaVebInputStream kvis) {
		this.kvos = kvos;
		this.kvis = kvis;
		this.kverr = kvos;
		in = kvis;
		out = new PrintStream(kvos, true);
		err = new PrintStream(kverr, true);
	}
	
	public WebConsoleProgram(KonzolaVebOutputStream kvos, KonzolaVebInputStream kvis, KonzolaVebOutputStream kverr) {
		this.kvos = kvos;
		this.kvis = kvis;
		this.kverr = kvos;
		in = kvis;
		out = new PrintStream(kvos, true);
		err = new PrintStream(kverr, true);
	}
	
	@Override
	public final void run() {
		try {
			stareted = true; 
			go(); 
		}catch(Exception ex) {
			error = ex; 
			throw new RuntimeException(ex);
		}
		finally {
			endded = true; 
		}
	} 
	
	public abstract void go() throws Exception; 
	
	public final boolean isEndded() {
		return endded; 
	}
	
	public final boolean isStarted() {
		return stareted; 
	}
	
	public final Throwable error() {
		return error; 
	}
	
	public final  boolean inError() {
		return error!=null;
	}
}
