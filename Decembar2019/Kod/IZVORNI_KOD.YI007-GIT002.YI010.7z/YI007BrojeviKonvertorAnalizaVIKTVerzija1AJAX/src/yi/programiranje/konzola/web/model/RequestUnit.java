package yi.programiranje.konzola.web.model;

import java.io.Serializable;

import yi.programiranje.konzola.web.controller.KonzolaServiceServlet.RequestType;

public class RequestUnit implements Serializable{
	private static final long serialVersionUID = 538608986307514201L;
	private RequestType requestType; 
	private String inputContent;
	private String pageId; 
	
	public RequestUnit(String pageId) {
		this.requestType = RequestType.REQUEST; 
		this.pageId = pageId; 
	}
	
	public RequestUnit(RequestType type, String pageId) {
		if(type==null) throw new NullPointerException(); 
		this.requestType = type; 
		this.pageId = pageId; 
	}
	
	public RequestUnit(String pageId, String input) {
		this.requestType = RequestType.REQUEST; 
		this.inputContent = input;
		this.pageId = pageId; 
	}
	
	public RequestUnit(RequestType type,  String pageId, String input) {
		if(type==null) throw new NullPointerException(); 
		this.requestType = type; 
		this.inputContent = input; 
		this.pageId = pageId; 
	}
	
	public RequestType getRequestType() {
		return requestType;
	}
	public String getInputContent() {
		return inputContent;
	} 
	public String pageId() {
		return pageId;
	}
	
	public boolean isRequest() {
		return this.requestType == RequestType.REQUEST; 
	}
	public boolean hasInput() {
		return this.inputContent !=null;
	}
	public boolean isIdentified() {
		return pageId != null; 
	}
}
