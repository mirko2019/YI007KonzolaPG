package yi.programiranje.konzola.web.ws.signal;

import java.io.IOException;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import yi.programiranje.konzola.web.controller.KonzolaServiceSignalizer;
import yi.programiranje.konzola.web.controller.KonzolaServiceSupport;
    
@ServerEndpoint("/KonzolaSignal")
public class KonzolaPageSignalServerWS {

    @OnOpen
    public void open(Session session) {
    	new KonzolaServiceSignalizer(session,this);
    	try {
			session.getBasicRemote().sendText(session.getId());
		} catch (IOException e) {
			KonzolaServiceSupport.stop(session.getId());
			KonzolaServiceSignalizer.close(session);
		}
    }

    @OnClose
    public void close(Session session) {
    	KonzolaServiceSupport.stop(session.getId());
    	KonzolaServiceSignalizer.close(session);
    }

    @OnError
    public void onError(Throwable error) {
    	KonzolaServiceSupport.stop(KonzolaServiceSignalizer.get(this).getId());
    	KonzolaServiceSignalizer.close(this);
    }

    @OnMessage
    public void handleMessage(String message, Session session) {
    }
}   