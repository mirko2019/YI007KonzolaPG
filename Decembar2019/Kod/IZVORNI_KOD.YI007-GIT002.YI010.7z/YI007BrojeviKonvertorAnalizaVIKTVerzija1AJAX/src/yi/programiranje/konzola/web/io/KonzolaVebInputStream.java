package yi.programiranje.konzola.web.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

public class KonzolaVebInputStream  extends InputStream {
	private boolean closed; 
	private Object synchron;
	private boolean onInput; 
	private String buffer = "";
	private boolean returnLineInfo = true; 
	
	public KonzolaVebInputStream() {
		buffer = ""; 
		synchron = new Object(); 
	}
	
	public KonzolaVebInputStream(byte[] by) {
		buffer = "";
		synchron = new Object();
	}
	
	public KonzolaVebInputStream(Object synchron) {
		buffer = "";
		this.synchron = synchron; 
	}
	
	public KonzolaVebInputStream(Object synchron, byte[] by) {
		buffer = "";
		this.synchron = synchron; 
	}
	
	public Object getSynchron() {
		return synchron; 
	}
	
	public String getBuffer() {
		return buffer; 
	}

	@Override
	public int read() throws IOException {
		if(closed) return -1; 
		if(buffer.length()==0) {
			if(returnLineInfo) {
				synchronized(synchron) {
					onInput = true; 
					try{synchron.wait();}
					catch(Exception ex) {throw new RuntimeException(ex);}
				}
			}else {
				returnLineInfo = true;
				return -1; 
			}
		}
		char c = buffer.charAt(0); 
		buffer = buffer.substring(1);
		if(buffer.length()==0) {
			returnLineInfo = false; 
		}
		return c;
	}
	
	@Override 
	public int available() {
		return buffer.length(); 
	}
	
	public void clear() {
		buffer = ""; 
	}
	
	public void setContent(byte[] by) throws UnsupportedEncodingException {
		if(closed) return; 
		onInput = false;
		buffer = new String(by,"UTF-8")+"\n"; 
		synchronized(synchron) {synchron.notifyAll();} 
	}
	
	public void addContent(byte[] by) throws IOException {
		if(closed) return; 
		onInput = false;
		buffer = buffer + new String(by,"UTF-8")+"\n"; 
		synchronized(synchron) {synchron.notifyAll();} 
	}
	
	@Override
	public void close() throws IOException {
		if(closed) return; 
		synchronized(synchron) {
			synchron.notifyAll(); 
		}
		super.close(); 
		closed = true; 
		onInput = false; 
	}
	
	public boolean isClosed() {
		return closed; 
	}
	
	public void waitUnconditionally() throws InterruptedException {
		synchronized(synchron) {
			if(!closed)
				synchron.wait();
		}
	}
	
	public void notifyUnconditionally() {
		synchronized(synchron) {
			synchron.notify(); 
		}
	}
	
	public boolean onInput() {
		synchronized(synchron) {
			return onInput; 
		}
	}
	
	@Override
	public void reset() throws IOException {
		super.reset();
		buffer=""; 
		returnLineInfo=true;
	}
}