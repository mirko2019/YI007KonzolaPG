package yi.programiranje.konzola.web.io;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class KonzolaVebOutputStream extends OutputStream{
	private ByteArrayOutputStream buffer; 
	private Object synchron; 
	private boolean closed; 
	private boolean onOutput; 
	private boolean onClearScreen; 
	
	public KonzolaVebOutputStream() {
		synchron = new Object();
		buffer = new ByteArrayOutputStream();
	}
	
	public KonzolaVebOutputStream(Object synchron) {
		this.synchron = synchron;
		buffer = new ByteArrayOutputStream();
	}
	
	public ByteArrayOutputStream getBuffer() {
		return buffer; 
	}
	
	public Object getSynchron() {
		return synchron;
	}

	@Override
	public void write(int b) throws IOException {
		if(closed) return;
		onOutput = true; 
		if(b==-1) {
			synchronized(getBuffer()) {
				buffer.write(b);
			}
		}else {
			synchronized(synchron) {
				synchronized(getBuffer()) {
					buffer.write(b);
				}
			}
		}
	}
	
	@Override
	public void flush() throws IOException {
		super.flush();
		synchronized(synchron) {
			try {
				synchron.wait();
			}catch(Exception ex) {
				throw new RuntimeException(ex);
			}
		}
		synchronized(getBuffer()) {
			buffer.flush();
			buffer = new ByteArrayOutputStream();
		}
	}
	
	public byte[] getContent() throws IOException{
		onOutput=false; 
		if(closed) { 
			byte[] bfx = buffer.toByteArray(); 
			buffer = new ByteArrayOutputStream();
			return bfx;
		}; 
		byte[] by = null; 
		synchronized(getBuffer()) {
			by = buffer.toByteArray();	
			buffer = new ByteArrayOutputStream();
		}
		synchronized(synchron) {
			notifyUnconditionally();
		}
		onOutput=true; 
		return by; 
	}
	
	public void notifyUnconditionally() {
		synchronized(synchron) {
			synchron.notify(); 
		}
	}
	
	public void notifyIfContainsContent() {
		if(buffer.toByteArray().length!=0) 
			notifyUnconditionally(); 
	}
	
	@Override
	public void close() throws IOException {
		synchronized(buffer) {
			synchronized(synchron) {
				synchron.notifyAll(); 
			}
			super.close();
			buffer.close();
			System.gc();
			closed = true; 
			onClearScreen = false; 
			onOutput = false; 
		}
	}

	
	public void waitUnconditionally() throws InterruptedException {
		synchronized(synchron) {
			if(!closed)
				synchron.wait();
		}
	}
	
	public boolean isClosed() {
		return closed;
	}
	
	public boolean onOutput() {
		return onOutput; 
	}
	
	
	public synchronized boolean getOnClearScreen() { 
			boolean resx = onClearScreen;
			return resx; 
	}
	
	public boolean getAndResetOnClearScreen() {
		boolean resx = onClearScreen; 
		onClearScreen = true;
		return resx; 
	}
	
	public synchronized void setOnClearScreen(boolean state) {
		if(closed) return; 
		onClearScreen = true; 
	}
}
