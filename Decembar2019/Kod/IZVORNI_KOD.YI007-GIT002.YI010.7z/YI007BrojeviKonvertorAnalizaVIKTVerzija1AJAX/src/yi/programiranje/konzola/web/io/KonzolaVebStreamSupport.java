package yi.programiranje.konzola.web.io;

public class KonzolaVebStreamSupport {
	private KonzolaVebOutputStream output;
	private KonzolaVebInputStream input;
	private Object synchron = new Object();
	
	public KonzolaVebStreamSupport() {
		output = new KonzolaVebOutputStream(); 
		input = new KonzolaVebInputStream(); 
	}
	
	public KonzolaVebStreamSupport(KonzolaVebInputStream input, KonzolaVebOutputStream output) {
		this.input = input; 
		this.output = output; 
	}
	
	public KonzolaVebInputStream getInput() {
		return input; 
	}
	
	public KonzolaVebOutputStream getOutput() {
		return output; 
	}
	
	public Object getSynchron() {
		return synchron;
	}
	
	public boolean onInput() {
		return input.onInput();  
	}
	
	public boolean onOutput() {
		return output.onOutput(); 
	}
	
	public boolean onClearOutputScreen() {
		return output.getOnClearScreen(); 
	}
}
