package yi.programiranje.program.cli;

import java.math.BigInteger;
import java.util.List;
import java.util.Scanner;

import yi.programiranje.algorithm.FactorialTools;
import yi.programiranje.contoller.FactoradixConvertor;
import yi.programiranje.contoller.FixBaseArabConvertor;
import yi.programiranje.contoller.RomeConvertor;
import yi.programiranje.engine.StringEngine;
import yi.programiranje.konzola.web.io.KonzolaVebInputStream;
import yi.programiranje.konzola.web.io.KonzolaVebOutputStream;
import yi.programiranje.konzola.web.model.WebConsoleProgram;
import yi.programiranje.model.ArabNumber;
import yi.programiranje.model.FactoradixNumber;
import yi.programiranje.program.util.text.TextTableMaystor;

public class WebConsoleApplication extends WebConsoleProgram{
	public WebConsoleApplication(KonzolaVebOutputStream kvos, KonzolaVebInputStream kvis,
			KonzolaVebOutputStream kverr) {
		super(kvos, kvis, kverr);
	}

	public WebConsoleApplication(KonzolaVebOutputStream kvos, KonzolaVebInputStream kvis) {
		super(kvos, kvis);
	}

	private Scanner scanner = new Scanner(in);
	private FactorialTools factoriel = new FactorialTools(); 
	private FixBaseArabConvertor fixBasedNumber = new FixBaseArabConvertor(); 
	private RomeConvertor romeNumber = new RomeConvertor(); 
	private FactoradixConvertor afineBasedNumber = new FactoradixConvertor(); 
	
	public int menu() {
		out.println("MENI : ");
		out.println("0. Izlaz");
		out.println("1. Racunanje faktorijela");
		out.println("2. Prtvorba dekadnog arapskog broja u ostale");
		out.println("3. Prtvorba oktalnog arapskog broja u ostale");
		out.println("4. Prtvorba binarnog arapskog broja u ostale");
		out.println("5. Prtvorba heksadecimalnog broja u ostale");
		out.println("6. Prtvorba rimskog broja u ostale");
		out.println("7. Prtvorba faktoradiksa (faktorijelnog broja)");
		out.println("8. Zapis faktorijela kroz brojne sisteme");
		out.println("9. Pronalazenje zadate permutacije datog broja"); 
		out.println("10. Pretvaranje broja u zadatu fiksnu bazu");
		out.println("11. Pretvaranje broja iz zadate fiksne baze"); 
		out.print("IZBOR: "); 
		try {
			return scanner.nextInt(); 
		}catch(Exception ex) {
			ex.printStackTrace();
			scanner = new Scanner(in); 
			return -1; 
		}
	}
	
	public void function1() {
		out.println("RACUNANJE FAKTORIJELA");
		while(true) {
			out.print("Unesi vrijednost operanda 0-1000 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.compareTo(new BigInteger("1000"))>0) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				factoriel.setNumber(numa);
				BigInteger res = factoriel.factoriel().getNumber(); 
				if(res.toString().length()>100) {
					out.println(num.toString()+"! = ");
					for(int i=0; i<res.toString().length(); i++) {
						if(i%100==0) out.print("\n\t");
						out.print(res.toString().charAt(i));
					}
					out.println("\n"); 
				}else {
					out.println(num.toString()+"! = "+res.toString());	
				}
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public void function2() {
		out.println("PRETVORBA DEKADNOG BROJA U OSTALE FORMATE");
		while(true) {
			out.print("Unesi vrijednost broja 1-10000 cifara, veca od 0 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				out.println("BINARNO"); binaryPrint(); 
				out.println("OKTALNO"); octalPrint(); 
				out.println("DEKADNO"); decadePrint(); 
				out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(num.compareTo(new BigInteger("4000"))<0) 
					out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					out.println("RIMSKI : Nije definisan.");
				
				out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public void function3() {
		out.println("PRETVORBA OKTALNOG BROJA U OSTALE FORMATE");
		while(true) {
			out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums,8);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				out.println("BINARNO"); binaryPrint(); 
				out.println("OKTALNO"); octalPrint(); 
				out.println("DEKADNO"); decadePrint(); 
				out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(num.compareTo(new BigInteger("4000"))<0) 
					out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					out.println("RIMSKI : Nije definisan.");
				
				out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public void function4() {
		out.println("PRETVORBA BINARNOG BROJA U OSTALE FORMATE");
		while(true) {
			out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums,2);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				out.println("BINARNO"); binaryPrint(); 
				out.println("OKTALNO"); octalPrint(); 
				out.println("DEKADNO"); decadePrint(); 
				out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(num.compareTo(new BigInteger("4000"))<0) 
					out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					out.println("RIMSKI : Nije definisan.");
				
				out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public void function5() {
		out.println("PRETVORBA HEKSADECIMALNOG BROJA U OSTALE FORMATE");
		while(true) {
			out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums,16);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				out.println("BINARNO"); binaryPrint(); 
				out.println("OKTALNO"); octalPrint(); 
				out.println("DEKADNO"); decadePrint(); 
				out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(num.compareTo(new BigInteger("4000"))<0) 
					out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					out.println("RIMSKI : Nije definisan.");
				
				out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public void function6() {
		out.println("PRETVORBA RIMSKOG BROJA U OSTALE FORMATE");
		while(true) {
			out.print("Unesi vrijednost rimskog broja npr. I : ");
			String nums = scanner.next(); 
			try {
				romeNumber.getNumber().setNumber(nums);
				BigInteger num = romeNumber.get();
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				out.println("BINARNO"); binaryPrint(); 
				out.println("OKTALNO"); octalPrint(); 
				out.println("DEKADNO"); decadePrint(); 
				out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(num.compareTo(new BigInteger("4000"))<0) 
					out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					out.println("RIMSKI : Nije definisan.");
				
				out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public void function7() {
		out.println("PRETVORBA FAKTORADIKSA U OSTALE FORMATE");
		out.println("Kao cifre koriste se mala ili velika slova engleskog alfabeta [0-26] i cifre brojeva - poziciona baza - radiks");
		out.println("Ravnopravna specifikacija cifara je koristenje brojeva sa fiksnom bazom u zagradama da se oznace cifre");
		out.println("Unos u mjesovitoj notaciji npr. (11)b(10)987654(3)210. Primjer ...az(38)(10)a. Bitno je da format radiksa bude ispostovan i oznake.");
		out.println("Vidi se da sve cifre moraju biti navedene do vodece, a vodece nule ne smetaju.");
		out.println(); 
		while(true) {
			out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next();
			out.print("Unesi zadanu bazu za zapis cifara u zagradama[2-36]: ");
			try {
				int base = Integer.parseInt(scanner.next());
				if(base<2 || base>36) throw new RuntimeException("Neodgovarajuca baza za brojeve sa fiksnom bazom"); 
				FactoradixNumber formatter = new FactoradixNumber();
				formatter.fromMixed(nums, base);
				BigInteger num = formatter.toInteger();
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				out.println("BINARNO"); binaryPrint(); 
				out.println("OKTALNO"); octalPrint(); 
				out.println("DEKADNO"); decadePrint(); 
				out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				out.println("SA FIKSNOM BAZOM "+base); fixedBasePrint(base);
				if(num.compareTo(new BigInteger("4000"))<0) 
					out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					out.println("RIMSKI : Nije definisan.");
				
				out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public void function8() {
		out.println("RACUNANJE FAKTORIJELA I ZAPIS PO BROJNIM SISTEMIMA");
		while(true) {
			out.print("Unesi vrijednost operanda 0-1000 : ");
			String nums = scanner.next(); 
			try {
				BigInteger num = new BigInteger(nums);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.compareTo(new BigInteger("1000"))>0) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				factoriel.setNumber(numa);
				numa.setNumber(factoriel.factoriel().getNumber()); 
				fixBasedNumber.setNumber(numa);
				if(numa.getNumber().compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(numa.getNumber());
				out.println("BINARNO"); binaryPrint(); 
				out.println("OKTALNO"); octalPrint(); 
				out.println("DEKADNO"); decadePrint(); 
				out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				if(numa.getNumber().compareTo(new BigInteger("4000"))<0) 
					out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					out.println("RIMSKI : Nije definisan.");
				
				out.println();
				afineBasedNumber.getNumber().fromInteger(numa.getNumber());
				out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public void function9() {
		out.println("PREGLED PERMUTACIJA PO LEKSIKOGRAFSKOM POREDKU ZA STRING");
		out.println();
		out.print("Unesi string : ");
		String line = scanner.nextLine();
		while(line.length()==0) {
			line = scanner.nextLine(); 
		}
		StringEngine lineEngine = new StringEngine(line); 
		out.println("Broj permutacija (razmjstaja znakova) : "+lineEngine.countDeploys()); 
		out.println("Indeks tekuceg razmjestaja [prvi]: "+lineEngine.firstIndexOf()); 
		out.println();
		BigInteger index = new BigInteger("0");
		int len = 0; 
		while(true) {
			try {
				out.print("Unesi pocetni indeks za pretragu : ");
				String ln = scanner.next();
				index = new BigInteger(ln);
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
		while(true) {
			try {
				out.print("Unesi broj permutacija od indeksa : ");
				len = scanner.nextInt();
				break; 
			}catch(Exception ex) {
				scanner = new Scanner(in); 
				continue; 
			}
		}
		List<String> result = lineEngine.getDeployOn(index, len); 
		out.println("\nPRONALAZCI");
		out.println(); 
		for(String res: result) {
			out.println("\t"+res); 
		}
	}
	
	public void function10() {
		out.println("PRETVORBA DEKADNOG BROJA U BROJ SA ZADATOM FIKSNOM BAZOM I U OSTALE FORMATE");
		out.println("Kao cifre koriste se mala ili velika slova engleskog alfabeta [0-26]");
		while(true) {
			out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next();
			out.print("Unesi zadanu bazu [2-36]: ");
			try {
				int base = Integer.parseInt(scanner.next());
				if(base<2 || base>36) throw new RuntimeException("Neodgovarajuca baza za brojeve sa fiksnom bazom"); 
				BigInteger num = new BigInteger(nums,10);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				out.println("BINARNO"); binaryPrint(); 
				out.println("OKTALNO"); octalPrint(); 
				out.println("DEKADNO"); decadePrint(); 
				out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				out.println("SA FIKSNOM BAZOM "+base); fixedBasePrint(base);
				if(num.compareTo(new BigInteger("4000"))<0) 
					out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					out.println("RIMSKI : Nije definisan.");
				
				out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public void function11() {
		out.println("PRETVORBA BROJA SA ZADATOM FIKSNOM BAZOM U OSTALE FORMATE");
		out.println("Kao cifre koriste se mala ili velika slova engleskog alfabeta [0-26]");
		while(true) {
			out.print("Unesi vrijednost broja 1-10000 cifara dekadno, veca od 0 : ");
			String nums = scanner.next();
			out.print("Unesi zadanu bazu [2-36]: ");
			try {
				int base = Integer.parseInt(scanner.next());
				if(base<2 || base>36) throw new RuntimeException("Neodgovarajuca baza za brojeve sa fiksnom bazom"); 
				BigInteger num = new BigInteger(nums,base);
				if(num.compareTo(new BigInteger("0"))<0) continue; 
				if(num.toString().length()>10000) continue;
				ArabNumber numa = new ArabNumber(); 
				numa.setNumber(num);
				fixBasedNumber.setNumber(numa);
				if(num.compareTo(new BigInteger("4000"))<0) 
					romeNumber.set(num);
				out.println("BINARNO"); binaryPrint(); 
				out.println("OKTALNO"); octalPrint(); 
				out.println("DEKADNO"); decadePrint(); 
				out.println("HEKSADECIMNALNO"); hexadecimalPrint(); 
				out.println("SA FIKSNOM BAZOM "+base); fixedBasePrint(base);
				if(num.compareTo(new BigInteger("4000"))<0) 
					out.println("RIMSKI : "+romeNumber.getNumber().getNumber());
				else
					out.println("RIMSKI : Nije definisan.");
				
				out.println();
				afineBasedNumber.getNumber().fromInteger(num);
				out.println("FAKTORADIKS OSNOVNI ZAPIS");
				factoradixBasicPrint(); 
				out.println("FAKTORADIKS UOPSTENI ZAPIS");
				factoradixGeneralPrint(); 
				break; 
			}catch(Exception ex) {
				continue; 
			}
		}
	}
	
	public void factoradixGeneralPrint() {
		List<Integer> digits = afineBasedNumber.getNumber().getNumber(); 
		String[][] mat = new String[digits.size()/10+(digits.size()%10==0?0:1)][10]; 
		for(int i=0; i<mat.length; i++) {
			mat[i] = new String[10]; 
			for(int j=0; j<mat[i].length; j++)
				mat[i][j]="0"; 
		}
		for(int i=0; i<digits.size(); i++) {
			mat[mat.length-i/10-1][i%10] = Integer.toString(digits.get(i)); 
		}
		TextTableMaystor tm = new TextTableMaystor(mat);
		mat = tm.fitTableStringize(); 
		
		for(int i=0; i<mat.length; i++) {
			out.println(); 
			for(int j=0; j<mat[i].length; j++)
				out.print(mat[i][mat[i].length-j-1]+" "); 
		}
		
		out.println();
	}
	
	public void factoradixBasicPrint() {
		String number = afineBasedNumber.toBasicFactoradixString(); 
		for(int i=0; i<number.length(); i++) {
			if(i%100==0) out.print("\n\t"); 
			out.print(number.charAt(i));
		}
		out.println();
		out.println(); 
	}
	
	public void fixedBasePrint(int radix) {
		String number = fixBasedNumber.to(radix); 
		String pad = ""; 
		int padding = (5-number.length()%5)%5; 
		for(int i=0; i<padding; i++) {
			pad+="0"; 
		}
		number = pad+number;
		for(int i=0; i<number.length(); i++) {
			if(i%100==0) out.print("\n\t");
			if(i%5==0 && i%100!=0) out.print(" ");
			if(i%20==0 && i%100!=0) out.print(" ");
			out.print(number.charAt(i));
		}
		out.println();
		out.println();
	}
	
	public void binaryPrint() {
		String number = fixBasedNumber.toBinary(); 
		String pad = ""; 
		int padding = (8-number.length()%8)%8;
		for(int i=0; i<padding; i++) {
			pad+="0"; 
		}
		number = pad+number; 
		for(int i=0; i<number.length(); i++) {
			if(i%64==0) out.print("\n\t");
			if(i%8==0 && i%64!=0) out.print(" ");
			if(i%16==0 && i%64!=0) out.print(" "); 
			out.print(number.charAt(i));
		}
		out.println();
		out.println();
	}
	
	public void octalPrint() {
		String number = fixBasedNumber.toOctal(); 
		String pad = ""; 
		int padding = (3-number.length()%3)%3; 
		for(int i=0; i<padding; i++) {
			pad+="0"; 
		}
		number = pad+number;
		for(int i=0; i<number.length(); i++) {
			if(i%60==0) out.print("\n\t");
			if(i%3==0 && i%60!=0) out.print(" ");
			if(i%12==0 && i%60!=0) out.print(" "); 
			out.print(number.charAt(i));
		}
		out.println();
		out.println();
	}
	
	public void decadePrint() {
		String number = fixBasedNumber.toDecade(); 
		String pad = ""; 
		int padding = (5-number.length()%5)%5; 
		for(int i=0; i<padding; i++) {
			pad+="0"; 
		}
		number = pad+number;
		for(int i=0; i<number.length(); i++) {
			if(i%100==0) out.print("\n\t");
			if(i%5==0 && i%100!=0) out.print(" ");
			if(i%20==0 && i%100!=0) out.print(" ");
			out.print(number.charAt(i)); 
		}
		out.println();
		out.println();
	}
	
	public void hexadecimalPrint() {
		String number = fixBasedNumber.toHexadecimal();
		String pad = ""; 
		int padding = (2-number.length()%2)%2;
		for(int i=0; i<padding; i++) {
			pad+="0"; 
		}
		number = pad+number;
		for(int i=0; i<number.length(); i++) {
			if(i%64==0) out.print("\n\t");
			if(i%2==0 && i%64!=0) out.print(" ");
			if(i%16==0 && i%64!=0) out.print(" ");
			out.print(number.charAt(i));
		}
		out.println();
		out.println();
	}
	
	@Override
	public void go() {
		out.println(">> BROJEVI - KONVERTORI BROJEVA - DOBRODOSLNI <<");
		while(true) {
			out.println();
			int izbor = menu(); 
			kvos.setOnClearScreen(true);
			if(izbor==0) break;
			out.println(); 
			switch(izbor) {
				case 1:
					function1();
					break; 
				case 2: 
					function2();
					break; 
				case 3: 
					function3();
					break; 
				case 4: 
					function4(); 
					break; 
				case 5: 
					function5(); 
					break; 
				case 6: 
					function6(); 
					break; 
				case 7: 
					function7(); 
					break; 
				case 8: 
					function8(); 
					break;
				case 9: 
					function9(); 
					break; 
				case 10: 
					function10(); 
					break; 
				case 11: 
					function11(); 
					break; 
				default: 
					out.println("POGRESAN IZBOR!");
					break; 
			}
		}
		out.println(); 
		out.println(">> BROJEVI - KONVERTORI BROJEVA - DOVIDJENJA  <<");
	}	
	
}
