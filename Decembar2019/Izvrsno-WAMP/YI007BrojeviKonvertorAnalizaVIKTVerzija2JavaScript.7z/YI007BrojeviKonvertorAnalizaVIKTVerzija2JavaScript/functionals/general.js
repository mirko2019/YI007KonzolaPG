"UTF-8"

function inputKeyPress(event, actionsEnviroment){
	if(event.keyCode===13){
		var output = document.getElementById('output');
		var input = document.getElementById('input');
		actionsEnviroment.actionsMemory['input']=input.value;
		output.value+=input.value+"\n";
		input.value = ''; 
		input.setAttribute('readonly','');
		executeActions(actionsEnviroment);
		event.preventDefault(); 
	}
}

function clearInput(){
	document.getElementById('input').value='';
}

function clearOutput(){
	document.getElementById('output').value=''; 
}

function readLine(){
	var input = document.getElementById('input');
	input.removeAttribute('readonly');
}

function writeLine(text){
	var output = document.getElementById('output');
	output.value += text+"\n"; 
}

function getInput(actionsEnviroment){
	var result = actionsEnviroment.actionsMemory['input']; 
	actionsEnviroment.actionsMemory['input']=''; 
	return result; 
}


function write(text){
	var output = document.getElementById('output');
	output.value += text; 
}

function executeActions(actionsEnviroment){ 
	for(;actionsEnviroment.actionsCounter<actionsEnviroment.actionsLength; actionsEnviroment.actionsCounter++){
		actionsEnviroment.actions[actionsEnviroment.actionsCounter](); 
		if(actionsEnviroment.actions[actionsEnviroment.actionsCounter]===readLine) {
			actionsEnviroment.actionsCounter++;
			break; 
		}
	}
}

function loadProgram(){
	clearInput(); 
	clearOutput();
	actionsEnviroment.actions = []; 
	actionsEnviroment.actionsMemory = []; 
	actionsEnviroment.actionsLength = 0;  
	actionsEnviroment.actionsCounter = 0; 
	
	actionsEnviroment.actionsLength = 0;
	actionsEnviroment.actionsMemory['input']='';
	
	var activityCode = '';
	if(window.location.protocol=="file:"){
		var path = window.location.href; 
		if(path.endsWith('/')) path = path.substr(0,path.length-1); 
		else path = path.substring(0,path.lastIndexOf('/'));
		activityCode = loadJSFunctionalFrom(path,'activity'); 
	}else{
		activityCode = loadJSFunctional('activity');
	}
	var functionEnvParse = /function\W+activity\W*(\W*)\W*[{](.|\W)*?[}]/i;
	var actionsCode = activityCode.match(functionEnvParse);
	
	if(actionsCode.length>0){
		var actionsRegex = /[^{].*;/g; 
		var actionStatements = actionsCode[0].match(actionsRegex);  
		
		for(var i=0; i<actionStatements.length; i++){
			var readLineCallRX = /\W*readLine\W*(\W*)\W*;/i; 
			var readLineCallST = actionStatements[i].match(readLineCallRX);
			
			if(readLineCallST!=null && readLineCallST.length>0){
				actionsEnviroment.actions[actionsEnviroment.actionsLength] = readLine; 
			}
			else {
				eval("actionsEnviroment.actions[actionsEnviroment.actionsLength] = function(){"+actionStatements[i]+"}");
			}
			actionsEnviroment.actionsLength++; 
		}
	}
	input.setAttribute('readonly','');
	executeActions(actionsEnviroment); 
}
